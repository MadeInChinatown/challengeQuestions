/**

## Reference Material

1. [CS61A Summer 2014 Discussion 1](http://www-inst.eecs.berkeley.edu/~cs61a/su14/hw/hw1/hw1.html)
2. [CS61A Summer 2014 Course Material](http://www-inst.eecs.berkeley.edu/~cs61a/su14/)

> Disclaimer:  I am not a lawyer and I do not own any of the above content. This content was adapted to use Swift instead of Python purely for educational (non commercial) purposes. Please visit the above references material for the original educational content.
## Want to Contribute?

> Want to help improve our content? Feel free to create a pull request and help us keep our material fresh and error free 😁.

*/
